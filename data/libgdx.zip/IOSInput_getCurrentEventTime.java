@Override
public long getCurrentEventTime() {
    return currentEvent.timestamp;
}
