public void setN(SWIGTYPE_p_p_btSoftBody__Node value) {
    SoftbodyJNI.btSoftBody_Tetra_n_set(swigCPtr, this, SWIGTYPE_p_p_btSoftBody__Node.getCPtr(value));
}
