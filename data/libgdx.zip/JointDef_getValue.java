public int getValue() {
    return value;
}
