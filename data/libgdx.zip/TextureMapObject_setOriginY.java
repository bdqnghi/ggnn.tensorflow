/**
 * @param y new axis origin
 */
public void setOriginY(float y) {
    this.originY = y;
}
