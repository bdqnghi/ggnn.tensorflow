public float getMaxForce() {
    return m_maxForce;
}
