public OutputStream write(boolean overwrite) {
    throw new UnsupportedOperationException();
}
