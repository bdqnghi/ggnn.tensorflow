public static int SwigDirector_btIDebugDraw_getDebugMode(btIDebugDraw jself) {
    return jself.getDebugMode();
}
