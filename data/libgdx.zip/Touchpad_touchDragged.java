@Override
public void touchDragged(InputEvent event, float x, float y, int pointer) {
    calculatePositionAndValue(x, y, false);
}
