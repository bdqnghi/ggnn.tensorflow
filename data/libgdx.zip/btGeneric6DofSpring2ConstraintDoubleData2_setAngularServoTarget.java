public void setAngularServoTarget(btVector3DoubleData value) {
    DynamicsJNI.btGeneric6DofSpring2ConstraintDoubleData2_angularServoTarget_set(swigCPtr, this, btVector3DoubleData.getCPtr(value), value);
}
