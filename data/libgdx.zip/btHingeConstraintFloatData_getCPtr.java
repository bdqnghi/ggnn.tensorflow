public static long getCPtr(btHingeConstraintFloatData obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
