public void setPadding3(String value) {
    CollisionJNI.btConvexHullShapeData_padding3_set(swigCPtr, this, value);
}
