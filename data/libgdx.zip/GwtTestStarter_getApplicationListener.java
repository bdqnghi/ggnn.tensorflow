@Override
public ApplicationListener getApplicationListener() {
    return new GwtTestWrapper();
}
