public float getAzimuth() {
    return 0;
}
