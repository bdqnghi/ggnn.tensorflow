public static long getCPtr(btMaterial obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
