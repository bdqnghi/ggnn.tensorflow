public int getRows() {
    return getRows(address);
}
