public void setInternalType(int value) {
    CollisionJNI.btCollisionObjectFloatData_internalType_set(swigCPtr, this, value);
}
