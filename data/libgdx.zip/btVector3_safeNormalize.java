public Vector3 safeNormalize() {
    return LinearMathJNI.btVector3_safeNormalize(swigCPtr, this);
}
