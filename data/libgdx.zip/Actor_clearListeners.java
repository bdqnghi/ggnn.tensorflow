/**
 * Removes all listeners on this actor.
 */
public void clearListeners() {
    listeners.clear();
    captureListeners.clear();
}
