protected int protectedArrayOffset() {
    throw new UnsupportedOperationException();
}
