@Override
public Orientation getNativeOrientation() {
    return Orientation.Landscape;
}
