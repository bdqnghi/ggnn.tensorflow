public void setName(String value) {
    CollisionJNI.btCollisionObjectDoubleData_name_set(swigCPtr, this, value);
}
