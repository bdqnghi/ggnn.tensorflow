public float getMotorTargetVelosity() {
    return DynamicsJNI.btHingeConstraint_getMotorTargetVelosity(swigCPtr, this);
}
