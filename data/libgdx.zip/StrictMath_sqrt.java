public static double sqrt(double a) {
    return Math.sqrt(a);
}
