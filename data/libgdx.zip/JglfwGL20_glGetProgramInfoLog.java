public String glGetProgramInfoLog(int program) {
    return GL.glGetProgramInfoLog(program);
}
