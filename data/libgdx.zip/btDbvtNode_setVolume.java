public void setVolume(btDbvtAabbMm value) {
    CollisionJNI.btDbvtNode_volume_set(swigCPtr, this, btDbvtAabbMm.getCPtr(value), value);
}
