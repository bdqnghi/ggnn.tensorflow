public void setUnscaledPointsDoublePtr(btVector3DoubleData value) {
    CollisionJNI.btConvexHullShapeData_unscaledPointsDoublePtr_set(swigCPtr, this, btVector3DoubleData.getCPtr(value), value);
}
