public void setLinks(SWIGTYPE_p_p_btDbvtProxy value) {
    CollisionJNI.btDbvtProxy_links_set(swigCPtr, this, SWIGTYPE_p_p_btDbvtProxy.getCPtr(value));
}
