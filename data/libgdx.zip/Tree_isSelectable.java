public boolean isSelectable() {
    return selectable;
}
