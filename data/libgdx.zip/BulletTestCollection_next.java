public void next() {
    titleLabel.setText("Loading...");
    loading = 1;
}
