public void setClampCells(int value) {
    SoftbodyJNI.btSparseSdf3_clampCells_set(swigCPtr, this, value);
}
