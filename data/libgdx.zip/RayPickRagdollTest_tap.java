@Override
public boolean tap(float x, float y, int count, int button) {
    shoot(x, y);
    return true;
}
