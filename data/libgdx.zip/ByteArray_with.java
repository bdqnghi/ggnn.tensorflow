/**
 * @see #ByteArray(byte[])
 */
static public ByteArray with(byte... array) {
    return new ByteArray(array);
}
