/**
 * Returns the y-coordinate of the polygon's position within the world.
 */
public float getY() {
    return y;
}
