public static long SwigDirector_btBulletWorldImporter_createCylinderShapeX(btBulletWorldImporter jself, float radius, float height) {
    return btCollisionShape.getCPtr(jself.createCylinderShapeX(radius, height));
}
