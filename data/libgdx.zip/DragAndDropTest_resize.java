public void resize(int width, int height) {
    stage.getViewport().update(width, height, true);
}
