public void setHighMin(float highMin) {
    this.highMin = highMin;
}
