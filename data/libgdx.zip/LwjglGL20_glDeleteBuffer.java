@Override
public void glDeleteBuffer(int buffer) {
    GL15.glDeleteBuffers(buffer);
}
