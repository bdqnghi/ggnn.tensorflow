public void clear() {
    CollisionJNI.btDbvt_clear(swigCPtr, this);
}
