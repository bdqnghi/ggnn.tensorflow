public void setIdentity() {
    ex.x = (float) 1;
    ex.y = (float) 0;
    ex.z = (float) 0;
    ey.x = (float) 0;
    ey.y = (float) 1;
    ey.z = (float) 0;
    ez.x = (float) 0;
    ez.y = (float) 0;
    ez.z = (float) 1;
}
