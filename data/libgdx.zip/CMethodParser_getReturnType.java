public String getReturnType() {
    return returnType;
}
