public void setNode(btDbvtNode value) {
    CollisionJNI.btCompoundShapeChild_node_set(swigCPtr, this, btDbvtNode.getCPtr(value), value);
}
