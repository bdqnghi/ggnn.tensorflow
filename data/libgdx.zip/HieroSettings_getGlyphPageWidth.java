/**
 * @see UnicodeFont#getGlyphPageWidth()
 */
public int getGlyphPageWidth() {
    return glyphPageWidth;
}
