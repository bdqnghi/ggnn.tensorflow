public void setScontacts(SWIGTYPE_p_btAlignedObjectArrayT_btSoftBody__SContact_t value) {
    SoftbodyJNI.btSoftBody_scontacts_set(swigCPtr, this, SWIGTYPE_p_btAlignedObjectArrayT_btSoftBody__SContact_t.getCPtr(value));
}
