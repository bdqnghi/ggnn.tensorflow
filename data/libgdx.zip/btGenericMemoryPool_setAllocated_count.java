public void setAllocated_count(long value) {
    CollisionJNI.btGenericMemoryPool_allocated_count_set(swigCPtr, this, value);
}
