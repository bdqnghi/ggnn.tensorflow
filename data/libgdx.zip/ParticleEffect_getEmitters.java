public Array<ParticleEmitter> getEmitters() {
    return emitters;
}
