public int getNumPerturbationIterations() {
    return CollisionJNI.btConvex2dConvex2dAlgorithm_CreateFunc_numPerturbationIterations_get(swigCPtr, this);
}
