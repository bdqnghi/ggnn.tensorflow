public short[] getTriangles() {
    return triangles;
}
