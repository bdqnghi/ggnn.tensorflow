public int getUseOffsetForConstraintFrame() {
    return DynamicsJNI.btGeneric6DofConstraintDoubleData2_useOffsetForConstraintFrame_get(swigCPtr, this);
}
