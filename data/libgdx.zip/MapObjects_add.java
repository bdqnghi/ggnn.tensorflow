/**
 * @param object instance to be added to the collection
 */
public void add(MapObject object) {
    this.objects.add(object);
}
