public void setSoftnessOrthoLin(float softnessOrthoLin) {
    DynamicsJNI.btSliderConstraint_setSoftnessOrthoLin(swigCPtr, this, softnessOrthoLin);
}
