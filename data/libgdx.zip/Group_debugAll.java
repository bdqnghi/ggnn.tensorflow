/**
 * Calls {@link #setDebug(boolean, boolean)} with {@code true, true}.
 */
public Group debugAll() {
    setDebug(true, true);
    return this;
}
