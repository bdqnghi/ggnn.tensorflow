@Override
protected boolean protectedHasArray() {
    return false;
}
