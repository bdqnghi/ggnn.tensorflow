public void setTimescale(float value) {
    SoftbodyJNI.btSoftBody_Config_timescale_set(swigCPtr, this, value);
}
