public static long getCPtr(RaycastInfo obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
