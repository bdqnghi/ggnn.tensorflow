/**
 * The cell values that will be used as the defaults for all cells.
 */
public Cell defaults() {
    return cellDefaults;
}
