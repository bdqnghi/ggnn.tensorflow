public void setValue(int value) {
    CollisionJNI.btIntIndexData_value_set(swigCPtr, this, value);
}
