/**
 * Called when the mouse wheel has been scrolled. When true is returned, the event is {@link Event#handle() handled}.
 */
public boolean scrolled(InputEvent event, float x, float y, int amount) {
    return false;
}
