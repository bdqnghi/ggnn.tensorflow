@Override
public int getY(int pointer) {
    return touchY[pointer];
}
