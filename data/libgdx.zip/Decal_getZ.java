/**
 * @return position on the z axis
 */
public float getZ() {
    return this.position.z;
}
