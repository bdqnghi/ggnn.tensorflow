public void setAttached(boolean attached) {
    this.attached = attached;
}
