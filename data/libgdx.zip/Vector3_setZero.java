@Override
public Vector3 setZero() {
    this.x = 0;
    this.y = 0;
    this.z = 0;
    return this;
}
