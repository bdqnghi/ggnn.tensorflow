public void setDistance(float dist) {
    CollisionJNI.btManifoldPoint_setDistance(swigCPtr, this, dist);
}
