public CharBuffer compact() {
    throw new ReadOnlyBufferException();
}
