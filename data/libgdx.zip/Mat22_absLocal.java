/* djm: added */
public final void absLocal() {
    ex.absLocal();
    ey.absLocal();
}
