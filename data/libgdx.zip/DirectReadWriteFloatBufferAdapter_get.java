@Override
public float get(int index) {
    // }
    return floatArray.get(index);
}
