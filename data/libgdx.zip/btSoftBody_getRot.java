public Matrix3 getRot() {
    return SoftbodyJNI.btSoftBody_Pose_rot_get(swigCPtr, this);
}
