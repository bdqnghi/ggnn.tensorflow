public void setChildMargin(float value) {
    CollisionJNI.btCompoundShapeChildData_childMargin_set(swigCPtr, this, value);
}
