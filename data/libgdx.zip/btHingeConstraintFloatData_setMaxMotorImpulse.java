public void setMaxMotorImpulse(float value) {
    DynamicsJNI.btHingeConstraintFloatData_maxMotorImpulse_set(swigCPtr, this, value);
}
