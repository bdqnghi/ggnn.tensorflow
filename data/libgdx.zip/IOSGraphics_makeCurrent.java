void makeCurrent() {
    EAGLContext.setCurrentContext(context);
}
