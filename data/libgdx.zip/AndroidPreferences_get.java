@Override
public Map<String, ?> get() {
    return sharedPrefs.getAll();
}
