public Vector3 tMins() {
    return CollisionJNI.btDbvtAabbMm_tMins(swigCPtr, this);
}
