public btElement getElement(int index) {
    return new btElement(CollisionJNI.btUnionFind_getElement__SWIG_0(swigCPtr, this, index), false);
}
