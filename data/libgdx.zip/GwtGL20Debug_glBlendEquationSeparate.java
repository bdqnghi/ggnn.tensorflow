@Override
public void glBlendEquationSeparate(int modeRGB, int modeAlpha) {
    super.glBlendEquationSeparate(modeRGB, modeAlpha);
    checkError();
}
