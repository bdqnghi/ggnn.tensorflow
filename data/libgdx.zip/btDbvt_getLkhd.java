public int getLkhd() {
    return CollisionJNI.btDbvt_lkhd_get(swigCPtr, this);
}
