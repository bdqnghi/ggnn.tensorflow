public boolean wantsSleeping() {
    return DynamicsJNI.btRigidBody_wantsSleeping(swigCPtr, this);
}
