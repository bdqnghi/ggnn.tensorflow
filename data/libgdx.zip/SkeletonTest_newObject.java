@Override
protected Vector3 newObject() {
    return new Vector3();
}
