public float getMaximumDistanceSquared() {
    return CollisionJNI.btDiscreteCollisionDetectorInterface_ClosestPointInput_maximumDistanceSquared_get(swigCPtr, this);
}
