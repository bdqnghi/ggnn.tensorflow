@Override
protected VoronoiDiagramTask[] newArray(int size) {
    return new VoronoiDiagramTask[size];
}
