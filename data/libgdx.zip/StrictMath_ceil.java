public static double ceil(double a) {
    return Math.ceil(a);
}
