public void setAngle(float value) {
    LinearMathJNI.GrahamVector3_angle_set(swigCPtr, this, value);
}
