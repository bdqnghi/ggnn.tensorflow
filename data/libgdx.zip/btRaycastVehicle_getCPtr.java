public static long getCPtr(btVehicleTuning obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
