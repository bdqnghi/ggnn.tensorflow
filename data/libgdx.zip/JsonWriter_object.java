public JsonWriter object(String name) throws IOException {
    return name(name).object();
}
