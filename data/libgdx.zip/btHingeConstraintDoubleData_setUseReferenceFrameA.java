public void setUseReferenceFrameA(int value) {
    DynamicsJNI.btHingeConstraintDoubleData_useReferenceFrameA_set(swigCPtr, this, value);
}
