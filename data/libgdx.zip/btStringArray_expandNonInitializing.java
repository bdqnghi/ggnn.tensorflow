public String expandNonInitializing() {
    return ExtrasJNI.btStringArray_expandNonInitializing(swigCPtr, this);
}
