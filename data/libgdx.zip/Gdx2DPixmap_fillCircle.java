public void fillCircle(int x, int y, int radius, int color) {
    fillCircle(basePtr, x, y, radius, color);
}
