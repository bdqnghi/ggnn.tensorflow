public void internalSetAppliedImpulse(float appliedImpulse) {
    DynamicsJNI.btTypedConstraint_internalSetAppliedImpulse(swigCPtr, this, appliedImpulse);
}
