public void setAnchors(SWIGTYPE_p_btAlignedObjectArrayT_btSoftBody__Anchor_t value) {
    SoftbodyJNI.btSoftBody_anchors_set(swigCPtr, this, SWIGTYPE_p_btAlignedObjectArrayT_btSoftBody__Anchor_t.getCPtr(value));
}
