public void setHitPointLocal(Vector3 value) {
    CollisionJNI.LocalConvexResult_setHitPointLocal(swigCPtr, this, value);
}
