public void setNewpairs(int value) {
    CollisionJNI.btDbvtBroadphase_newpairs_set(swigCPtr, this, value);
}
