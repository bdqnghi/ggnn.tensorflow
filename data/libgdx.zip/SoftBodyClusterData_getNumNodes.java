public int getNumNodes() {
    return SoftbodyJNI.SoftBodyClusterData_numNodes_get(swigCPtr, this);
}
