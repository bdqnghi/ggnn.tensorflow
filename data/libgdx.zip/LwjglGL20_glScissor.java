public void glScissor(int x, int y, int width, int height) {
    GL11.glScissor(x, y, width, height);
}
