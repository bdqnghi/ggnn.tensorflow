public boolean isActive() {
    return alwaysActive || active;
}
