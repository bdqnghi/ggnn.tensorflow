public String getJniType() {
    return jniType;
}
