public static long getCPtr(btGEN_Link obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
