@Override
public AudioDevice newAudioDevice(int samplingRate, boolean isMono) {
    // TODO Auto-generated method stub
    return null;
}
