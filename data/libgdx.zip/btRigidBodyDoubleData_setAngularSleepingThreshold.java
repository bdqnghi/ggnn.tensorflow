public void setAngularSleepingThreshold(double value) {
    DynamicsJNI.btRigidBodyDoubleData_angularSleepingThreshold_set(swigCPtr, this, value);
}
