public void setRl(float value) {
    SoftbodyJNI.btSoftBody_Link_rl_set(swigCPtr, this, value);
}
