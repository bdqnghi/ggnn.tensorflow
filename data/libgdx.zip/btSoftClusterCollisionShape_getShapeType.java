public int getShapeType() {
    return SoftbodyJNI.btSoftClusterCollisionShape_getShapeType(swigCPtr, this);
}
