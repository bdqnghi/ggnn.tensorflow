public void setLinearStiffness(float value) {
    SoftbodyJNI.SoftBodyMaterialData_linearStiffness_set(swigCPtr, this, value);
}
