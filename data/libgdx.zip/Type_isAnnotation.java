public boolean isAnnotation() {
    return isAnnotation;
}
