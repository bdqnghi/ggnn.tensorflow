@Override
public Pixmap consumePixmap() {
    throw new GdxRuntimeException("This TextureData implementation does not return a Pixmap");
}
