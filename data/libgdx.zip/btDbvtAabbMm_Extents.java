public Vector3 Extents() {
    return CollisionJNI.btDbvtAabbMm_Extents(swigCPtr, this);
}
