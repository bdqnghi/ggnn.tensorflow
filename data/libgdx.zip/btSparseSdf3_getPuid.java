public int getPuid() {
    return SoftbodyJNI.btSparseSdf3_puid_get(swigCPtr, this);
}
