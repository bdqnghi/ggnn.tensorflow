public StaticTiledMapTile[] getFrameTiles() {
    return frameTiles;
}
