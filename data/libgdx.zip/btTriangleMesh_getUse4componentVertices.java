public boolean getUse4componentVertices() {
    return CollisionJNI.btTriangleMesh_getUse4componentVertices(swigCPtr, this);
}
