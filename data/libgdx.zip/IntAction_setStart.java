/**
 * Sets the value to transition from.
 */
public void setStart(int start) {
    this.start = start;
}
