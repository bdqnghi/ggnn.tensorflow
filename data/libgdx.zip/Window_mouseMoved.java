public boolean mouseMoved(InputEvent event, float x, float y) {
    return isModal;
}
