/*
		b2Joint* joint = (b2Joint*)addr;
		return joint->GetReactionTorque(inv_dt);
	*/
// /// Get the next joint the world joint list.
// b2Joint* GetNext();
// 
/**
 * Get the user data
 */
public Object getUserData() {
    return userData;
}
