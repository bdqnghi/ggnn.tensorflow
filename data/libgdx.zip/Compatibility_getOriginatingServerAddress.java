public static String getOriginatingServerAddress() {
    return impl.getOriginatingServerAddress();
}
