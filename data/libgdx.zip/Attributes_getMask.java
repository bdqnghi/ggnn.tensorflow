/**
 * @return Bitwise mask of the ID's of all the containing attributes
 */
public final long getMask() {
    return mask;
}
