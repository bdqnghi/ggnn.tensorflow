public int getUnused3() {
    return CollisionJNI.btUsageBitfield_unused3_get(swigCPtr, this);
}
