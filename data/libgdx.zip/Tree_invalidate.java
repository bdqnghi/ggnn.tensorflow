public void invalidate() {
    super.invalidate();
    sizeInvalid = true;
}
