/**
 * @return May be null.
 */
public boolean getUniformX() {
    return uniformX;
}
