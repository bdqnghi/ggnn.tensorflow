public float getBaumgarte() {
    return SoftbodyJNI.SoftBodyConfigData_baumgarte_get(swigCPtr, this);
}
