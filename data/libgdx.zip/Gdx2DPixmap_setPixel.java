public void setPixel(int x, int y, int color) {
    setPixel(basePtr, x, y, color);
}
