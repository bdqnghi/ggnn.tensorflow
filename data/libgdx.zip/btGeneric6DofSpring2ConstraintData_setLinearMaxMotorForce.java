public void setLinearMaxMotorForce(btVector3FloatData value) {
    DynamicsJNI.btGeneric6DofSpring2ConstraintData_linearMaxMotorForce_set(swigCPtr, this, btVector3FloatData.getCPtr(value), value);
}
