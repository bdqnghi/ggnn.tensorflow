public void setUpIndex(int value) {
    CollisionJNI.btConeShapeData_upIndex_set(swigCPtr, this, value);
}
