public void updateChildTransform(int childIndex, Matrix4 newChildTransform) {
    CollisionJNI.btCompoundShape_updateChildTransform__SWIG_1(swigCPtr, this, childIndex, newChildTransform);
}
