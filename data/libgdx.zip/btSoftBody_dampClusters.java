public void dampClusters() {
    SoftbodyJNI.btSoftBody_dampClusters(swigCPtr, this);
}
