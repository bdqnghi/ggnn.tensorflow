public float[] getScaling() {
    return scaling;
}
