public void glDrawElements(int mode, int count, int type, int indices) {
    GL.glDrawElements(mode, count, type, indices);
}
