/*
			return ((FT_Size_Metrics*)metrics)->height;
		*/
public int getMaxAdvance() {
    return getMaxAdvance(address);
}
