public void setPercentage(float percent) {
    slider.setValue((int) (1000 * percent));
}
