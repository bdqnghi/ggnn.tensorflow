/**
 * Starts iterating over the list's items from the tail of the list
 */
public void iterReverse() {
    iter = tail;
}
