/**
 * @return circle shape
 */
public Circle getCircle() {
    return circle;
}
