@Override
public <T> T[] getSpans(int arg0, int arg1, Class<T> arg2) {
    Log.d("Editable", "getSpans");
    return null;
}
