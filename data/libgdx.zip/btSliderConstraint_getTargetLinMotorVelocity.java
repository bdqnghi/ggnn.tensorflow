public float getTargetLinMotorVelocity() {
    return DynamicsJNI.btSliderConstraint_getTargetLinMotorVelocity(swigCPtr, this);
}
