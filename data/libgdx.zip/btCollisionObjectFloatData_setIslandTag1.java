public void setIslandTag1(int value) {
    CollisionJNI.btCollisionObjectFloatData_islandTag1_set(swigCPtr, this, value);
}
