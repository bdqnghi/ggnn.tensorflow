@Override
public boolean supportsExtension(String extension) {
    return false;
}
