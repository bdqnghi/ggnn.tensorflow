@Override
public void setPosition(float position) {
    track.setCurrentTime(position);
}
