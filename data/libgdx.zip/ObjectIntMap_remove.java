public void remove() {
    super.remove();
}
