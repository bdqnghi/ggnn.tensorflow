public float getKAST() {
    return SoftbodyJNI.btSoftBody_Material_kAST_get(swigCPtr, this);
}
