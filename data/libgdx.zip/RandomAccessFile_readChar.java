public final char readChar() throws IOException {
    return dis.readChar();
}
