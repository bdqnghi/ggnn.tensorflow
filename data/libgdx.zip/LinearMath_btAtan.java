public static float btAtan(float x) {
    return LinearMathJNI.btAtan(x);
}
