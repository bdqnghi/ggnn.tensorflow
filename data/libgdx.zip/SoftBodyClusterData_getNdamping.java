public float getNdamping() {
    return SoftbodyJNI.SoftBodyClusterData_ndamping_get(swigCPtr, this);
}
