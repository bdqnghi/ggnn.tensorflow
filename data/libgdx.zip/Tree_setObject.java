/**
 * Sets an application specific object for this node.
 */
public void setObject(Object object) {
    this.object = object;
}
