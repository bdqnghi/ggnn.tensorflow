private void initUI() {
    setOpaque(false);
    setBackground(new Color(0, 0, 0));
    setForeground(new Color(255, 255, 255));
    setFocusPainted(false);
    setIcon(icon);
    setRolloverIcon(iconOver);
    setPressedIcon(iconPressed);
    setSelectedIcon(iconSelected);
    setRolloverSelectedIcon(iconOverSelected);
}
