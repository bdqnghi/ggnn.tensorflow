public void setNeedsFeedback(int value) {
    DynamicsJNI.btTypedConstraintDoubleData_needsFeedback_set(swigCPtr, this, value);
}
