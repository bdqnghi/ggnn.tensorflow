public float getCcdSquareMotionThreshold() {
    return CollisionJNI.btCollisionObject_getCcdSquareMotionThreshold(swigCPtr, this);
}
