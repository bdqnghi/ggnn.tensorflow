public float getWheelsDampingCompression() {
    return DynamicsJNI.btWheelInfoConstructionInfo_wheelsDampingCompression_get(swigCPtr, this);
}
