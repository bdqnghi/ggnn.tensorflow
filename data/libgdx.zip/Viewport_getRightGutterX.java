/**
 * Returns the right gutter (black bar) x in screen coordinates.
 */
public int getRightGutterX() {
    return screenX + screenWidth;
}
