public FloatBuffer compact() {
    throw new ReadOnlyBufferException();
}
