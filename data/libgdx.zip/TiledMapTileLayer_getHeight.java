/**
 * @return layer's height in tiles
 */
public int getHeight() {
    return height;
}
