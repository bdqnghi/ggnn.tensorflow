public void serializeSingleShape(SWIGTYPE_p_btSerializer serializer) {
    CollisionJNI.btCollisionShape_serializeSingleShape(swigCPtr, this, SWIGTYPE_p_btSerializer.getCPtr(serializer));
}
