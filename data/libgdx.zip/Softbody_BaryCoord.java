public static Vector3 BaryCoord(Vector3 a, Vector3 b, Vector3 c, Vector3 p) {
    return SoftbodyJNI.BaryCoord(a, b, c, p);
}
