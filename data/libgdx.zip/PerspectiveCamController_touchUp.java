@Override
public boolean touchUp(int x, int y, int pointer, int button) {
    mode = TransformMode.None;
    return true;
}
