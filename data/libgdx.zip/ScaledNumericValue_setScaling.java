public void setScaling(float[] values) {
    this.scaling = values;
}
