public void mouseClicked(MouseEvent event) {
    repaint();
}
