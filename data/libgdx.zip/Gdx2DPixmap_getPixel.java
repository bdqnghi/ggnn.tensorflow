public int getPixel(int x, int y) {
    return getPixel(basePtr, x, y);
}
