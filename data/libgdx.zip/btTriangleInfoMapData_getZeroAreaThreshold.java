public float getZeroAreaThreshold() {
    return CollisionJNI.btTriangleInfoMapData_zeroAreaThreshold_get(swigCPtr, this);
}
