public void setRollingFriction(float value) {
    CollisionJNI.btCollisionObjectFloatData_rollingFriction_set(swigCPtr, this, value);
}
