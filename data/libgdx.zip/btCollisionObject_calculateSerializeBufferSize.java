public int calculateSerializeBufferSize() {
    return CollisionJNI.btCollisionObject_calculateSerializeBufferSize(swigCPtr, this);
}
