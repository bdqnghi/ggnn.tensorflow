public void setEquilibriumPoint(float[] value) {
    DynamicsJNI.btGeneric6DofSpringConstraintData_equilibriumPoint_set(swigCPtr, this, value);
}
