/**
 * @return object's properties set
 */
public MapProperties getProperties() {
    return properties;
}
