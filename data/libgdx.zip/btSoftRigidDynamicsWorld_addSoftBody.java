public void addSoftBody(btSoftBody body) {
    SoftbodyJNI.btSoftRigidDynamicsWorld_addSoftBody__SWIG_2(swigCPtr, this, btSoftBody.getCPtr(body), body);
}
