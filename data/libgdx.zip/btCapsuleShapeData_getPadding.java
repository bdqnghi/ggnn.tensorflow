public String getPadding() {
    return CollisionJNI.btCapsuleShapeData_padding_get(swigCPtr, this);
}
