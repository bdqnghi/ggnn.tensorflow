public float getBiasFactor() {
    return DynamicsJNI.btAngularLimit_getBiasFactor(swigCPtr, this);
}
