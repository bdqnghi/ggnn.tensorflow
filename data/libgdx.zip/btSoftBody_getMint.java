public float getMint() {
    return SoftbodyJNI.btSoftBody_RayFromToCaster_mint_get(swigCPtr, this);
}
