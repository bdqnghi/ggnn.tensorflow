public void setRestitutionOrthoLin(float restitutionOrthoLin) {
    DynamicsJNI.btSliderConstraint_setRestitutionOrthoLin(swigCPtr, this, restitutionOrthoLin);
}
