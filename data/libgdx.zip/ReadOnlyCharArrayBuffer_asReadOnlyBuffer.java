public CharBuffer asReadOnlyBuffer() {
    return duplicate();
}
