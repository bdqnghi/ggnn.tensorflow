public void setActive(boolean active) {
    this.active = active;
}
