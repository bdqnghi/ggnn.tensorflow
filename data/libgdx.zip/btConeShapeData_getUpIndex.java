public int getUpIndex() {
    return CollisionJNI.btConeShapeData_upIndex_get(swigCPtr, this);
}
