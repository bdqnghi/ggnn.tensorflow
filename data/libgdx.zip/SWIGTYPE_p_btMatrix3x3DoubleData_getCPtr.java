protected static long getCPtr(SWIGTYPE_p_btMatrix3x3DoubleData obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
