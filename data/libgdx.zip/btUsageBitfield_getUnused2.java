public int getUnused2() {
    return CollisionJNI.btUsageBitfield_unused2_get(swigCPtr, this);
}
