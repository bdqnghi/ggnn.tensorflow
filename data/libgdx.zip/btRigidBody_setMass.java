public void setMass(float value) {
    DynamicsJNI.btRigidBody_btRigidBodyConstructionInfo_mass_set(swigCPtr, this, value);
}
