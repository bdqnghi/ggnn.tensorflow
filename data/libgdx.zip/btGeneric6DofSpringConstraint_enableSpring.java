public void enableSpring(int index, boolean onOff) {
    DynamicsJNI.btGeneric6DofSpringConstraint_enableSpring(swigCPtr, this, index, onOff);
}
