/**
 * @return May be null if this value is not set.
 */
public Value getPadLeftValue() {
    return padLeft;
}
