public ByteBuffer asReadOnlyBuffer() {
    return this;
}
