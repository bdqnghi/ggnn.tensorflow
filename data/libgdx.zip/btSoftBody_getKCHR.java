public float getKCHR() {
    return SoftbodyJNI.btSoftBody_Config_kCHR_get(swigCPtr, this);
}
