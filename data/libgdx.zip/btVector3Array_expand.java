public Vector3 expand() {
    return LinearMathJNI.btVector3Array_expand__SWIG_1(swigCPtr, this);
}
