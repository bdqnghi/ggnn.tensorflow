@Override
public void glDisable(int cap) {
    super.glDisable(cap);
    checkError();
}
