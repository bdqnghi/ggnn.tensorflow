public float getImageX() {
    return imageX;
}
