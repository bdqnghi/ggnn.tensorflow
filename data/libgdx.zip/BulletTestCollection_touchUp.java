@Override
public boolean touchUp(int x, int y, int pointer, int button) {
    return tests[testIndex].touchUp(x, y, pointer, button);
}
