public static TextureAttribute createBump(final TextureRegion region) {
    return new TextureAttribute(Bump, region);
}
