public boolean isManual() {
    return this.isManual;
}
