@Override
public void dispose() {
    batch.dispose();
    texture.dispose();
}
