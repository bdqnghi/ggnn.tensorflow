/**
 * Returns the padding below a glyph on the GlyphPage to allow for effects to be drawn.
 */
public int getPaddingBottom() {
    return paddingBottom;
}
