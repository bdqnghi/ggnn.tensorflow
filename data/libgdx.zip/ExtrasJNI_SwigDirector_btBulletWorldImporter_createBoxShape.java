public static long SwigDirector_btBulletWorldImporter_createBoxShape(btBulletWorldImporter jself, Vector3 halfExtents) {
    return btCollisionShape.getCPtr(jself.createBoxShape(halfExtents));
}
