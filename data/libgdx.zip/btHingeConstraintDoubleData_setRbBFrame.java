public void setRbBFrame(btTransformDoubleData value) {
    DynamicsJNI.btHingeConstraintDoubleData_rbBFrame_set(swigCPtr, this, btTransformDoubleData.getCPtr(value), value);
}
