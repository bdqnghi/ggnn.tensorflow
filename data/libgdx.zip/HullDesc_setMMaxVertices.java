public void setMMaxVertices(long value) {
    LinearMathJNI.HullDesc_mMaxVertices_set(swigCPtr, this, value);
}
