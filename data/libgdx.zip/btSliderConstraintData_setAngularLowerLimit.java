public void setAngularLowerLimit(float value) {
    DynamicsJNI.btSliderConstraintData_angularLowerLimit_set(swigCPtr, this, value);
}
