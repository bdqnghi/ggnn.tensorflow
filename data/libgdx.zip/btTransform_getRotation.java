public Quaternion getRotation() {
    return LinearMathJNI.btTransform_getRotation(swigCPtr, this);
}
