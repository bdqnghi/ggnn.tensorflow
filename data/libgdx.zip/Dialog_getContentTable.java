public Table getContentTable() {
    return contentTable;
}
