public static void SwigDirector_btIDebugDraw_drawContactPoint(btIDebugDraw jself, Vector3 PointOnB, Vector3 normalOnB, float distance, int lifeTime, Vector3 color) {
    jself.drawContactPoint(PointOnB, normalOnB, distance, lifeTime, color);
}
