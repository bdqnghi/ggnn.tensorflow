public static long getCPtr(Handle obj) {
    return (obj == null) ? 0 : obj.swigCPtr;
}
