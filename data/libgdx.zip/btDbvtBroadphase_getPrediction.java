public float getPrediction() {
    return CollisionJNI.btDbvtBroadphase_prediction_get(swigCPtr, this);
}
