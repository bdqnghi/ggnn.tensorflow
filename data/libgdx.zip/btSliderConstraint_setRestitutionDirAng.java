public void setRestitutionDirAng(float restitutionDirAng) {
    DynamicsJNI.btSliderConstraint_setRestitutionDirAng(swigCPtr, this, restitutionDirAng);
}
