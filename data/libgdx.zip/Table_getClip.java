public boolean getClip() {
    return clip;
}
