public void insertAfter(btGEN_Link link) {
    LinearMathJNI.btGEN_Link_insertAfter(swigCPtr, this, btGEN_Link.getCPtr(link), link);
}
