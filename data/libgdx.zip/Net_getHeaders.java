/**
 * Returns a Map<String, String> with the headers of the HTTP request.
 */
public Map<String, String> getHeaders() {
    return headers;
}
