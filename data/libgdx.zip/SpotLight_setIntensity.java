public SpotLight setIntensity(float intensity) {
    this.intensity = intensity;
    return this;
}
