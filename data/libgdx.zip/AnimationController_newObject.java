@Override
protected AnimationDesc newObject() {
    return new AnimationDesc();
}
