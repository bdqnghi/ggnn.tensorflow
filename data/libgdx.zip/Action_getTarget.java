/**
 * @return null if the action has no target.
 */
public Actor getTarget() {
    return target;
}
