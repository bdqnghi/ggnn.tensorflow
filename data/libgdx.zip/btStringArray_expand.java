public String expand() {
    return ExtrasJNI.btStringArray_expand__SWIG_1(swigCPtr, this);
}
