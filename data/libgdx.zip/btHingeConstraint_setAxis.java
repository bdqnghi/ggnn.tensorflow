public void setAxis(Vector3 axisInA) {
    DynamicsJNI.btHingeConstraint_setAxis(swigCPtr, this, axisInA);
}
