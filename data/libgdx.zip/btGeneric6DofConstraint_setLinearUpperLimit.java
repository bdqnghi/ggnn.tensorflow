public void setLinearUpperLimit(Vector3 linearUpper) {
    DynamicsJNI.btGeneric6DofConstraint_setLinearUpperLimit(swigCPtr, this, linearUpper);
}
