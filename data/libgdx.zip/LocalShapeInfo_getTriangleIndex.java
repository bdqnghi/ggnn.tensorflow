public int getTriangleIndex() {
    return CollisionJNI.LocalShapeInfo_triangleIndex_get(swigCPtr, this);
}
