public static void SwigDirector_btIDebugDraw_flushLines(btIDebugDraw jself) {
    jself.flushLines();
}
