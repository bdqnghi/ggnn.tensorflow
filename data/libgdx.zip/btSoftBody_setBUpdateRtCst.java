public void setBUpdateRtCst(boolean value) {
    SoftbodyJNI.btSoftBody_bUpdateRtCst_set(swigCPtr, this, value);
}
